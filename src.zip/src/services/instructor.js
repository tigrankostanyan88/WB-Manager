const AppError = require('../utils/appError');
const Files = require('../controllers/File');
const repo = require('../repositories/instructor');

module.exports = {
  getInstructor: async (startTime) => {
    const instructors = await repo.findAll({ includeFiles: true, includeAvatarOnly: true });

    return {
      instructors,
      time: `${Date.now() - startTime} ms`
    };
  },

  addInstructor: async (body, files, startTime) => {
    console.log('[addInstructor] START, files:', Object.keys(files || {}));

    let instructor = await repo.findOne({ includeFiles: true, includeAvatarOnly: true });
    let wasCreated = false;

    if (!instructor) {
      instructor = await repo.create(body);
      wasCreated = true;
    } else {
      await repo.update(instructor, body);
    }

    instructor = await repo.findOne({ includeFiles: true, includeAvatarOnly: true });

    // Handle avatar upload
    const filePayload = files?.avatar || files?.instructor_img || files?.image;

    if (filePayload && filePayload.name && filePayload.mimetype) {
      const modelForFiles = {
        id: instructor.id,
        files: Array.isArray(instructor.files) ? instructor.files : [],
        constructor: { name: 'instructors' }
      };

      const image = await new Files(modelForFiles, filePayload).replace('instructor_img');

      if (image.status !== 'success') {
        const msg = typeof image.message === 'object' ? Object.values(image.message).join(' ') : image.message;
        throw new AppError(msg, 400);
      }

      await instructor.createFile(image.table);
      
      const avatarUrl = `/images/instructors/large/${image.table.name}.${image.table.ext}`;
      await repo.update(instructor, { avatar_url: avatarUrl });
    }
    
    const finalInstructor = await repo.findOne({ includeFiles: true, includeAvatarOnly: true });
    
    return {
      instructor: finalInstructor,
      wasCreated,
      time: `${Date.now() - startTime} ms`
    };
  },

  updateInstructor: async (body, files) => {
    let instructor = await repo.findOne({ includeFiles: true, includeAvatarOnly: true });
    let wasCreated = false;

    if (!instructor) {
      instructor = await repo.create(body);
      wasCreated = true;
    } else {

      const existingAvatarUrl = instructor.avatar_url;
      const updateBody = { ...body };

      if ((!updateBody.avatar_url && existingAvatarUrl) || updateBody.avatar_url === null || updateBody.avatar_url === undefined) {
        updateBody.avatar_url = existingAvatarUrl;
      }

      await repo.update(instructor, updateBody);
    }

    instructor = await repo.findOne({ includeFiles: true, includeAvatarOnly: true });

    const filePayload = files?.instructor_img || files?.image || files?.avatar;

    if (filePayload && filePayload.name && filePayload.mimetype) {
      const modelForFiles = {
        id: instructor.id,
        files: Array.isArray(instructor.files) ? instructor.files : [],
        constructor: { name: 'instructors' }
      };

      
      const image = await new Files(modelForFiles, filePayload).replace('instructor_img');

      if (image.status !== 'success') {
        const msg = typeof image.message === 'object' ? Object.values(image.message).join(' ') : image.message;
        throw new AppError(msg, 400);
      }

      await instructor.createFile(image.table);
      
      const avatarUrl = `/images/instructors/large/${image.table.name}.${image.table.ext}`;
      await repo.update(instructor, { avatar_url: avatarUrl });
    }
    return repo.findOne({ includeFiles: true, includeAvatarOnly: true });
  },

  deleteInstructor: async (id) => {
    const instructor = await repo.findById(id);
    if (!instructor) throw new AppError('Instructor not found', 404);

    await repo.destroy(instructor);
  }
};
